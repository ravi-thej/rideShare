package com.hackathon.RideShare;

import java.util.List;

public class FeedbackForm {
	
	private String feedBack;
	private String comments;
	
	public String getFeedBack() {
		return feedBack;
	}
	public void setFeedBack(String feedBack) {
		this.feedBack = feedBack;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	

}
